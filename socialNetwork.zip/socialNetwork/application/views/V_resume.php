<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Resume</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css"/>
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" media="screen" title="no title"> -->


  </head>
  <body>
	<!----------------------------------------------------------------------------- Nav Bar --------------------------------------------------------- -->
		<!-- <nav class="navbar navbar-inverse navbar-static-top">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="<?php echo base_url('user/user_profile');?>"><?php echo $this->session->userdata('user_fname'); ?>'s Profile</a>
				</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">

					<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Resume<span class="caret"></span></a>
							<ul class="dropdown-menu">
								
								<li><a href="<?php echo base_url('C_resume/resume_view');?>">Create resume</a></li>
								<li><a href="<?php echo base_url('C_resume/resume');?>">resume</a></li>
								<li><a href="<?php echo base_url('C_resume/std_resume');?>">View resume</a></li>
							</ul>
						</li>
					
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Activities<span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li><a href="<?php echo base_url('user/user_profile');?>">Home</a></li>
								<li><a href="<?php echo base_url('Albums/index');?>">Album</a></li>
								<li><a href="<?php echo base_url('Chat/retrieveMsg');?>">Messages</a></li>
								<li><a href="<?php echo base_url('UserPost/list_post');?>">Posts</a></li>
								<li><a href="<?php echo base_url('UserGroup/list_group');?>">Subject Group</a></li>
								<li><a href="<?php echo base_url('C_crudUser/User_list');?>">Users</a></li>
								<li><a href="<?php echo base_url('C_conference/conference_view');?>">Conference</a></li>
								<li><a href="https://appr.tc/">Video Chat</a></li>
								
							</ul>
						</li>
						<li><a href="<?php echo base_url('user/user_logout');?>">Log Out</a></li>
					</ul>
				</div>
			</div>
		</nav> -->
		<?php include 'header\user_header.php'; ?>
<!-------------------------------------------------------------------------------------------------------------------------------------- -->
  
<span style="background-color:red;">
  <div class="container"><!-- container class is used to centered  the body of the browser with some decent width-->
      <div class="row"><!-- row class is used for grid system in Bootstrap-->
          <div class="col-md-4 col-md-offset-4"><!--col-md-4 is used to create the no of colums in the grid also use for medimum and large devices-->
              <div class="login-panel panel panel-success">
                  <div class="panel-heading">
                      <h3 class="panel-title">Rsume</h3>
                  </div>
                  <div class="panel-body">

                  <?php
                  $error_msg=$this->session->flashdata('error_msg');
                  if($error_msg){
                    echo $error_msg;
                  }
                   ?>

                      <form role="form" method="post" action="<?php echo base_url('C_resume/insert_resume'); ?>">
                          <fieldset>
						  
								<div class="form-group">
                                  <textarea class="form-control" placeholder="Samll Description About Yourself" name="descp" type="text" ></textarea>
                              </div>
							  
                              <div class="form-group">
                                  <input class="form-control" placeholder="First Name" name="user_fname" type="text" autofocus>
                              </div>
							  
							  <div class="form-group">
                                  <input class="form-control" placeholder="Last Name" name="user_lname" type="text" autofocus>
                              </div>

                            <div class="form-group">
                    			<select name="gender" id="gender" >
								  <option value="" disabled selected>Select Gender</option>
								  <option value="Male">Male</option>
								  <option value="Female">Female</option>
								</select>
							   </div>
							  
							   <!-- <div class="form-group">
					                <input type="file" name="pic_file" id="">   
            					</div> -->

							  <div class="form-group">
                                  <input class="form-control" placeholder="Address" name="address" type="text" >
                              </div>
							  
							  <div class="form-group">
                                  <input class="form-control" placeholder="Hobbies" name="hobbies" type="text" >
                              </div>
							  
							  <div class="form-group">
                                  <input class="form-control" placeholder="Languages Spoken" name="lang_spoken" type="text" >
                              </div>
							  
							  <div class="form-group">
                                  <input class="form-control" placeholder="School Name" name="ssc_Name" type="text" >
                              </div>
							  
							  <div class="form-group">
                                  <input class="form-control" placeholder="School Marks Obtained" name="ssc_Mks" type="text" >
                              </div>
							  
							  <div class="form-group">
                                  <input class="form-control" placeholder="Year Of Passing MM-YYYY" name="ssc_YOP" type="text" maxlength="7" minlength="7" pattern="[0-9]{2}-[0-9]{4}">
                              </div>
							  
							  <div class="form-group">
                                  <input class="form-control" placeholder="Hssc Name" name="Hssc_Name" type="text" >
                              </div>
							  
							  <div class="form-group">
                                  <input class="form-control" placeholder="Hssc Marks Obtained" name="Hssc_Mks" type="text" >
                              </div>
							  
							  <div class="form-group">
                                  <input class="form-control" placeholder="Year Of Passing MM-YYYY" name="Hssc_YOP" type="text" maxlength="7" minlength="7" pattern="[0-9]{2}-[0-9]{4}">
                              </div>
							  
							  <div class="form-group">
                                  <input class="form-control" placeholder="College Name" name="college_Name" type="text" >
                              </div>
							  
							  <div class="form-group">
                                  <input class="form-control" placeholder="Final Year Marks" name="college_Mks" type="text" >
                              </div>
							  
							  <div class="form-group">
                                  <input class="form-control" placeholder="Year Of Passing MM-YYYY" name="college_YOP" type="text" maxlength="7" minlength="7" pattern="[0-9]{2}-[0-9]{4}">
                              </div>
							  
							  <div class="form-group">
                                  <textarea class="form-control" placeholder="Work Experience" name="Wrk_exp" type="text" ></textarea>
                              </div>
							
                              <input class="btn btn-lg btn-success btn-block" type="submit" value="Resume Submit" name="register" >

                          </fieldset>
                      </form>
                     
                  </div>
              </div>
          </div>
      </div>
  </div>





</span>

	<script type="text/javascript" src="<?php echo base_url('js/register.js');?>"></script>
	<script type='text/javascript' src="<?php echo base_url();?>assets/js/jquery-3.3.1.min.js"></script><!--Googles-->
	<script type='text/javascript' src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

  </body>
</html>

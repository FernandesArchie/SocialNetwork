<html>
 <head>
	<title>Group View</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css"/>
 </head>
 <body onload="EnableNotes('<?php echo $this->session->userdata('user_type'); ?>')">
 <!----------------------------------------------------------------------------- Nav Bar --------------------------------------------------------- -->
		<!-- <nav class="navbar navbar-inverse navbar-static-top">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="<?php echo base_url('user/user_profile');?>"><?php echo $this->session->userdata('user_fname'); ?>'s Profile</a>
				</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">

						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Activities<span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li><a href="<?php echo base_url('user/user_profile');?>">Home</a></li>
								<li><a href="<?php echo base_url('Albums/index');?>">Album</a></li>
								<li><a href="<?php echo base_url('Chat/retrieveMsg');?>">Messages</a></li>
								<li><a href="<?php echo base_url('UserPost/list_post');?>">Posts</a></li>
								<li><a href="<?php echo base_url('C_crudUser/User_list');?>">Users</a></li>
								<li><a href="<?php echo base_url('UserGroup/list_group');?>">Subject Group</a></li>
								<li><a href="<?php echo base_url('C_conference/conference_view');?>">Conference</a></li>
								<li><a href="https://appr.tc/">Video Chat</a></li>
							</ul>
						</li>
						<li><a href="<?php echo base_url('user/user_logout');?>">Log Out</a></li>
					</ul>
				</div>
			</div>
		</nav> -->
		<?php include 'header\user_header.php'; ?>
	<!----------------------------------------------------------------------------------------------------------------------------------------- -->
	
	<?php $group_name;?>
	
	<!-- <a href="<?php //echo base_url('UserGroup/delete_group');?>" >  <button type="button" class="btn-primary">Delete Group</button></a> -->
	 <!-- <div>Notes List</div> -->
	<!-- <a href="<?php //echo base_url('UserGroup/upload_note');?>" >  <button type="button" class="btn-primary">Upload Note</button></a> -->
	
	<a id="notes_trs" href="<?php echo base_url('C_notes/notes_trs');?>" >  <button id="notes_trs" type="button" class="btn btn-primary btn-md">Add Notes</button></a>
	<a id="notes_student" href="<?php echo base_url('C_notes/notes_student');?>" >  <button id="notes_student" type="button" class="btn btn-primary btn-md">View Notes</button></a>
	
	<!-- <div>Assignment List with button to upload for each assignment</div> -->
	
	<script type='text/javascript' src="<?php echo base_url();?>assets/js/jquery-3.3.1.min.js"></script><!--Googles-->
	<script type='text/javascript' src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
	
	<script>
	function EnableNotes(user)
	{ 
		//alert(user);
		if(user=="student")
		{	 
			document.getElementById("notes_trs").style.display="none";		
		}
		
	}
	</script>
	
 </body>
</html>
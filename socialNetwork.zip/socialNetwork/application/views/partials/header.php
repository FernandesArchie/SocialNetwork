<head>
	<meta charset="utf-8">
	<title></title>

	<link rel="stylesheet" href="<?php echo base_url()?>application/third_party/libs/css/bootstrap.min.css">
	<script src="<?php echo base_url()?>application/third_party/libs/js/jquery-1.9.1.min.js"></script>

</head>

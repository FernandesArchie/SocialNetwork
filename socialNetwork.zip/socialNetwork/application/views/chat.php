<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Messages</title>
	

		
	<!-- ------------------------------------------------------------------------ style sheets------------------------------------------ -->
	 <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css"/>
	<script type='text/javascript' src="<?php echo base_url();?>assets/js/jquery-3.3.1.min.js"></script><!--Googles-->
	<script type='text/javascript' src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/chat.css" />
	<!-- -------------------------------------------------------------------------------------------------------------------------------- -->
	
</head>
<body>

<!--- ---------------------------------------------------------------- Nav Bar----------------------------------------------------- -->


<!--
<nav class="navbar navbar-inverse navbar-static-top">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="<?php echo base_url('user/user_profile');?>"><?php echo $this->session->userdata('user_fname'); ?>'s Profile</a>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav navbar-right">

					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Activities<span class="caret"></span></a>
						<ul class="dropdown-menu">
							<li><a href="<?php echo base_url('user/user_profile');?>">Home</a></li>
								<li><a href="<?php echo base_url('Albums/index');?>">Album</a></li>
								<li><a href="<?php echo base_url('Chat/retrieveMsg');?>">Messages</a></li>
								<li><a href="<?php echo base_url('UserPost/list_post');?>">Posts</a></li>
								<li><a href="<?php echo base_url('C_crudUser/User_list');?>">Users</a></li>
								<li><a href="<?php echo base_url('UserGroup/list_group');?>">Subject Group</a></li>
								<li><a href="<?php echo base_url('C_conference/conference_view');?>">Conference</a></li>
								<li><a href="https://appr.tc/">Video Chat</a></li>
						</ul>
					</li>
					<li><a href="<?php echo base_url('user/user_logout');?>">Log Out</a></li>
				</ul>
			</div>
		</div>
	</nav> -->
	<?php include 'header\user_header.php'; ?>


<!--------------------------------------------------------------------------------------------------------------------------------- -->
<form role="form" method="post" action="<?php echo base_url('Chat/storeMsg');?>">
	<div class="container">
		<div class="row">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<span class="glyphicon glyphicon-comment"></span> Messages
				</div>
				<div class="panel-body">
					<ul class="chat" id="received">
						<table class="table table-striped table-bordered">
						<tr><td><strong>Message</strong></td><td><strong>From</strong></td><td><strong>Date & time (24 Hrs)</strong></td></tr> 
						<?php foreach($msgs as $msg){?>
						<tr><td><?=$msg->message;?></td><td><?=$msg->sender;?></td><td><?=$msg->dt;?></td></tr> 
						<?php }?>
						</table>
					</ul>
				</div>
				<div class="panel-footer">
					
					<div class="clearfix">
						<div class="col-md-3">
							<div class="input-group">
								<span class="input-group-addon">
									To:
								</span>
								<input name="receiver" type="text" class="form-control input-sm" placeholder="Send Msg to..." value="" required/>
							</div>
						</div>
						<div class="col-md-9" id="msg_block">
							<div class="input-group">
								<input name="message" type="text" class="form-control input-sm" placeholder="Type your message here..." value=""/>
								<span class="input-group-btn">
								<button class="btn btn-warning btn-sm" id="submit" type="submit">Send</button>
								</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</form>
	<div class="container">
	  <a href="<?php echo base_url('user/user_profile'); ?>" >  <button type="button" class="btn btn-primary btn-lg">Go Back</button></a>
	  <a href="<?php echo base_url('Chat/vSentMsg'); ?>" >  <button type="button" class="btn btn-primary btn-lg">View sent Messages</button></a>
	</div>



</body>
</html>
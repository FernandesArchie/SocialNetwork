<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Album</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/MyStyles.css"/>
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
</head>

<?php include '\partials\header.php'; ?>
<?php //include '\partials\navbar.php'; ?>


<body><div > 
	<!----------------------------------------------------------------------------- Nav Bar --------------------------------------------------------- -->
		
		<?php include 'header\album_header.php'; ?>
<!-------------------------------------------------------------------------------------------------------------------------------------- -->
	
	<?php 
		if($title == 'Albums') include '\templates\album.php'; 
		elseif($title == 'Add/Edit Album') include '\templates\album_form.php'; 
		elseif($title == 'View Album') include '\templates\view_album.php';
	?>
	 <!-- <a class="btn btn-info navbar-btn" href="<?php //echo base_url().'Albums/album/create'?>">Add New Album</a> -->
	<!--<a href="<?php echo base_url().'Albums/album/create'?>" >  <button type="button" class="btn btn-primary btn-lg">Add New Album</button></a> -->
	</div>
	</body>
<?php include '\partials\footer.php'; ?>
</html>


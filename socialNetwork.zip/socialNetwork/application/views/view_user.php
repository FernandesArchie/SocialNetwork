<?php
$user_id=$this->session->userdata('user_id');

if(!$user_id){

  redirect('user/login_view');
}

 ?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>User Profile</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css"/>
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
  </head>
	<body>
	<!----------------------------------------------------------------------------- Nav Bar --------------------------------------------------------- -->
		<nav class="navbar navbar-inverse navbar-static-top">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="<?php echo base_url('user/user_profile');?>"><?php echo $this->session->userdata('user_fname'); ?>'s Profile</a>
				</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">

					<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Resume<span class="caret"></span></a>
							<ul class="dropdown-menu">
								
								<li><a href="<?php echo base_url('C_resume/resume_view');?>">Create resume</a></li>
								<li><a href="<?php echo base_url('C_resume/resume');?>">resume</a></li>
								<li><a href="<?php echo base_url('C_resume/std_resume');?>">View resume</a></li>
							</ul>
						</li>
					
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Activities<span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li><a href="<?php echo base_url('user/user_profile');?>">Home</a></li>
								<li><a href="<?php echo base_url('Albums/index');?>">Album</a></li>
								<li><a href="<?php echo base_url('Chat/retrieveMsg');?>">Messages</a></li>
								<li><a href="<?php echo base_url('UserPost/list_post');?>">Posts</a></li>
								<li><a href="<?php echo base_url('UserGroup/list_group');?>">Subject Group</a></li>
								<li><a href="<?php echo base_url('user/lists_user');?>">Users</a></li>
								<li><a href="<?php echo base_url('C_conference/conference_view');?>">Conference</a></li>
								<li><a href="https://appr.tc/">Video Chat</a></li>
								
							</ul>
						</li>
						<li><a href="<?php echo base_url('user/user_logout');?>">Log Out</a></li>
					</ul>
				</div>
			</div>
		</nav>
<!-------------------------------------------------------------------------------------------------------------------------------------- -->
<div class="jumbotron">
	<div class="container">
		<h1><?php echo $this->session->userdata('fuser_fname'); ?>'s Profile</h1>
		
		<div class="row">
			<div class="col-md-4">

			  <table class="table table-bordered table-striped">
				<tr>
				  <th colspan="2"><h4 class="text-center">User Info</h3></th>
				</tr>
				 <tr>
					<td>User id</td>
					<td><?php echo $this->session->userdata('fuser_id'); ?></td>
				  </tr>	  
				  <tr>
					<td>User Name</td>
					<td><?php echo $this->session->userdata('fuser_fname'); ?></td>
				  </tr>
				  <tr>
					<td>User Email</td>
					<td><?php echo $this->session->userdata('fuser_email');  ?></td>
				  </tr>
				  <tr>
					<td>User's DOB</td>
					<td><?php echo $this->session->userdata('fuser_dob');  ?></td>
				  </tr>
				  <tr>
					<td>User Mobile</td>
					<td><?php echo $this->session->userdata('fuser_mobile');  ?></td>
				  </tr>
			  </table>
			</div>
		</div>
	</div>
</div>
 <!------------------------------------------------------------------------------------------------------------------------------------------------------ -->
 

 <!----
	<a href="<?php// echo base_url('Albums/index');?>" >  <button type="button" class="btn-primary">Create Album</button></a>
	<a href="<?php //echo base_url('UserPost/load_post');?>" >  <button type="button" class="btn-primary">Posts</button></a>
	<a href="<?php //echo base_url('UserGroup/list_group');?>" >  <button type="button" class="btn-primary">Subject Group</button></a>
	<a href="<?php// echo base_url('C_crudUser/User_list');?>" >  <button type="button" class="btn-primary">Users</button></a>
	<a href="<?php //echo base_url('user/user_logout');?>" >  <button type="button" class="btn-primary">Logout</button></a>
	-->

	<!--------------------------------------------------------------- CSS Java Script ------------------------------------------------------------->
	<script type='text/javascript' src="<?php echo base_url();?>assets/js/jquery-3.3.1.min.js"></script><!--Googles-->
	<script type='text/javascript' src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
  </body>
</html>

<?php  
 function fetch_data()  
 {  
		//session_start();
      $output = '';  
      $conn = mysqli_connect("localhost", "root", "", "social_network");  
	  $uid = $_SESSION["user_id"]; 
      $sql = "SELECT * FROM resume where user_id = $uid ";  
      $result = mysqli_query($conn, $sql);  
      while($row = mysqli_fetch_array($result))  
      {       
	       $output .= '
						<h3>Description</h3>
						<p>'.$row["descp"].'</p>
						<h3>Basic Details</h3>
						<table>
						<tr>
                          <td>First Name</td><td>'.$row["firstName"].'</td>
						</tr>
						<tr>
							  <td>Last Name</td> <td>'.$row["lastName"].'</td>  
						</tr>
						<tr>
							 <td>Email</td> <td>'.$row["email"].'</td>  
						 </tr> 
						<tr>
							 <td>Gender</td> <td>'.$row["gender"].'</td>  
						 </tr> 
						 <tr>
							 <td>Date Of Birth</td> <td>'.$row["dob"].'</td>  
						 </tr>
						 <tr>
							 <td>Mobile</td> <td>'.$row["Mobile"].'</td>  
						 </tr>
						  <tr>
							 <td>Address</td> <td>'.$row["address"].'</td>  
						 </tr>
						 
					 <tr>
						 <td>Hobbies</td> <td>'.$row["hobbies"].'</td>  
                     </tr>
					 <tr>
						 <td>Languages Spoken</td> <td>'.$row["lang_spoken"].'</td>  
                     </tr>
					 </table>
					 
					 <h3>Educational Qualifications</h3>
					 <table>
					 <tr>
						<th><h4>Institute Name</h4></th>
						<th><h4>Year Of Passing</h4></th>
						<th><h4>Marks Obtained</h4></th>
						
					</tr>
					<tr>
						  <td>'.$row["ssc_Name"].'</td>  
						<td>'.$row["ssc_YOP"].'</td>  
							<td>'.$row["ssc_Mks"].'</td>  
                     </tr>
					 <tr>
						  <td>'.$row["Hssc_Name"].'</td>  
						<td>'.$row["Hssc_YOP"].'</td>  
						 <td>'.$row["Hssc_Mks"].'</td>  
                     </tr>
					 <tr>
						 <td>'.$row["college_Name"].'</td>  
						 <td>'.$row["college_YOP"].'</td>  
                      <td>'.$row["college_Mks"].'</td>  
                     </tr>
					 <table>
					 <h3>Work Experience</h3>
						<p>'.$row["Wrk_exp"].'</p>
                          ';  
      }  
      return $output;  
 }  
 if(isset($_POST["generate_pdf"]))  
 {  
      require_once('tcpdf/tcpdf.php');  
      $obj_pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);  
      $obj_pdf->SetCreator(PDF_CREATOR);  
      $obj_pdf->SetTitle("Resume Print");  
      $obj_pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);  
      $obj_pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));  
      $obj_pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));  
      $obj_pdf->SetDefaultMonospacedFont('helvetica');  
      $obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);  
      $obj_pdf->SetMargins(PDF_MARGIN_LEFT, '10', PDF_MARGIN_RIGHT);  
      $obj_pdf->setPrintHeader(false);  
      $obj_pdf->setPrintFooter(false);  
      $obj_pdf->SetAutoPageBreak(TRUE, 10);  
      $obj_pdf->SetFont('helvetica', '', 11);  
      $obj_pdf->AddPage();  
      $content = '';  
      $content .= '  
      <table border="0" cellspacing="0" cellpadding="1">  
           <tr>  
                <th ></th>  
                <th ></th>  
           </tr>  
      ';  
      $content .= fetch_data();  
		 $content .= '</table>';  
      $obj_pdf->writeHTML($content);  
      $obj_pdf->Output('file.pdf', 'I');  
 }  
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Print Resume</title>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />            
      </head>  
      <body>  
		<?php include 'header\user_header.php'; ?>
           <br />
           <div class="container">  
                <h4 align="center"> Resume</h4><br />  
                <div class="table-responsive">  
                	<div class="col-md-12" align="right">
                     <form method="post">  
                          <input type="submit" name="generate_pdf" class="btn btn-success" value="Generate PDF" />  
                     </form>  
                     </div>
                     <br/>
                     <br/>
                      <table border="0" >  
                          <!--<tr>  
                               <th width="5%">Id</th>  
							</tr>
							<tr>
                               <th width="30%">Name</th>  
                             </tr>
							<tr>
							   <th width="15%">Age</th>  
                               </tr>
							   <tr>
							   <th width="50%">Email</th>  
						  </tr> -->  
                     <?php  
                     echo fetch_data();  
                     ?>  
                     </table>  
                </div>  
           </div>  
      </body>  
 </html>  
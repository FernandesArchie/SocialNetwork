<?php
$user_id=$this->session->userdata('user_id');

if(!$user_id){

  redirect('user/login_view');
}
//Code Added 10th May 2018 Jessio
	$this->session->unset_userdata('fuser_id');
	$this->session->unset_userdata('fuser_email');
	$this->session->unset_userdata('fuser_fname');
	$this->session->unset_userdata('fuser_type');
	$this->session->unset_userdata('fuser_dob');
	$this->session->unset_userdata('fuser_mobile');
 ?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>User Home</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/MyStyles.css"/>
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
  </head>
	<body>
	<!----------------------------------------------------------------------------- Nav Bar --------------------------------------------------------- -->
		<?php include 'header\user_header.php'; ?>
<!-------------------------------------------------------------------------------------------------------------------------------------- -->

<div class="parallax">
	<div class="Left-User-Div">
		<h2>Hello <?php echo $this->session->userdata('user_fname'); ?></h2>
		<h3>Welcome</h3>
	</div>
	<div class="Right-User-Div">
		<p><h3>Where Would u Like To Go ?</h3></p>
		
		<p>
			<span><a href="<?php echo base_url('user/user_info'); ?>" >  <button type="button" class="btn btn-primary btn-md">Your Info</button></a></span>
			<span><a href="<?php echo base_url('Albums/index'); ?>" >  <button type="button" class="btn btn-primary btn-md">Albums</button></a></span>
			<span><a href="<?php echo base_url('UserGroup/list_group'); ?>" >  <button type="button" class="btn btn-primary btn-md">Subject Group</button></a></span>
		</P>
		<p>
			<span><a href="<?php echo base_url('Chat/retrieveMsg'); ?>" >  <button type="button" class="btn btn-primary btn-md">Messages</button></a></span>
			<span><a href="<?php echo base_url('UserPost/list_post'); ?>" >  <button type="button" class="btn btn-primary btn-md">Posts</button></a></span>
		</P>
		<p>
			<!-- <span><a href="<?php //echo base_url('C_crudUser/User_list'); ?>" >  <button type="button" class="btn btn-primary btn-md">Users</button></a></span> -->
			<span><a href="<?php echo base_url('user/lists_user'); ?>" >  <button type="button" class="btn btn-primary btn-md">Users</button></a></span>
			<span><a href="<?php echo base_url('C_conference/conference_view'); ?>" >  <button type="button" class="btn btn-primary btn-md">Conference</button></a></span>
			<span><a href="https://appr.tc/">  <button type="button" class="btn btn-primary btn-md">Video Chat</button></a></span>
		</P>
		
	</div>
</div>
 <!------------------------------------------------------------------------------------------------------------------------------------------------------ -->
 

 <!----
	<a href="<?php// echo base_url('Albums/index');?>" >  <button type="button" class="btn-primary">Create Album</button></a>
	<a href="<?php //echo base_url('UserPost/load_post');?>" >  <button type="button" class="btn-primary">Posts</button></a>
	<a href="<?php //echo base_url('UserGroup/list_group');?>" >  <button type="button" class="btn-primary">Subject Group</button></a>
	<a href="<?php// echo base_url('C_crudUser/User_list');?>" >  <button type="button" class="btn-primary">Users</button></a>
	<a href="<?php //echo base_url('user/user_logout');?>" >  <button type="button" class="btn-primary">Logout</button></a>
	-->

	<!--------------------------------------------------------------- CSS Java Script ------------------------------------------------------------->
	<script type='text/javascript' src="<?php echo base_url();?>assets/js/jquery-3.3.1.min.js"></script><!--Googles-->
	<script type='text/javascript' src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
  </body>
</html>

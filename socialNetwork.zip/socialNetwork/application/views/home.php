<!DOCTYPE html>
<html>
	<head>
    <meta charset="utf-8">
    <title>Login Registration</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/MyStyles.css"/>
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/Home.css"/>
	</head>
	
	<body>
		<!----------------------------------------------------------------------------- Nav Bar --------------------------------------------------------- -->
		<nav class="navbar navbar-inverse navbar-static-top">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<span class="navbar-brand">Social Networking</span>
				</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
				
						<li><a href="<?php echo base_url('user/login_view');?>">Log In</a></li>
					</ul>
				</div>
			</div>
		</nav>
		<!-------------------------------------------------------------------------------------------------------------------------------------- -->
	
		<div class="parallax">

			<div class="Left-Div">
			<p><h1>Welcome User<h1></p>
			<p><h4>This Web Application will help you connect to your teachers as well as other students</h4></p>
			<p><h3><strong>Sign up now and get started</strong></h3></p>
			</div>

			<div class="Right-Div">
			
				<div class="container"><!-- container class is used to centered  the body of the browser with some decent width-->
					<div class="row"><!-- row class is used for grid system in Bootstrap-->
						<div class="col-md-4 col-md-offset-4"><!--col-md-4 is used to create the no of colums in the grid also use for medimum and large devices-->
							<div class="login-panel panel panel-success">
								<div class="panel-heading">
									<h3 class="panel-title">Registration</h3>
								</div>
								<div class="panel-body">

									<?php
									$error_msg=$this->session->flashdata('error_msg');
									if($error_msg){
										echo $error_msg;
									}
									?>
				
				
									<!-------------------------------------- ------------------------- -->
									<form role="form" method="post" action="<?php echo base_url('user/register_user'); ?>">
										<fieldset>
												<div class="form-group">
												  <input class="form-control" placeholder="First Name" name="user_fname" type="text" autofocus required>
												</div>
											  
												<div class="form-group">
												  <input class="form-control" placeholder="Last Name" name="user_lname" type="text" autofocus required>
												</div>

												<div class="form-group">
												  <input class="form-control" placeholder="E-mail" name="user_email" type="email" autofocus required>
												</div>
											  
												<div class="form-group">
												  <input class="form-control" placeholder="Password" name="user_password" type="password" value="" required>
												</div>

												<div class="form-group">
												  <input class="form-control" placeholder="Date of Birth" name="user_dob" type="date" value="" required>
												</div>

												<div class="form-group">
												  <input class="form-control" placeholder="Mobile No" name="user_mobile" type="text" value="" pattern=".{10,}" required maxlength="10">
												</div>
												
												<div class="form-group">
												  <input class="form-control" placeholder="Address" name="user_address" type="text" required>
												</div>
											  
												<div class="form-group">
													<select name="user_type" id="user_type" onchange="EnableHidden();">
														<option value="" disabled selected>Select Role</option>
														<option value="student">student</option>
														<option value="teacher">teacher</option>
													</select>
												</div>
											  
												<div class="form-group">
													<select name="user_deptName" id=""  >
														<option value="" disabled selected>Select Your Department</option>
														<option value="MCA">MCA</option>
													</select>
												</div>
											   
												<div class="form-group" id="std_roll" hidden>
													<input class="form-control" placeholder="Roll Number" name="std_roll" type="text">
												</div>
											  
												<div class="form-group" id="std_joinDate" hidden>
													<input class="form-control" placeholder="Date of Joining" name="std_joinDate" type="date" value="">
												</div>
											   
											  
											
												<input class="btn btn-lg btn-success btn-block" type="submit" value="Register" name="register">

										</fieldset>
									</form>
									<center><b>Already registered ?</b> <br></b><a href="<?php echo base_url('user/login_view'); ?>">Login here</a></center><!--for centered text-->
								</div>
							</div>
						</div>
					</div>
				</div>
			
			</div>

		</div>
		<script type="text/javascript" src="<?php echo base_url('js/register.js');?>"></script>
		<script type='text/javascript' src="<?php echo base_url();?>assets/js/jquery-3.3.1.min.js"></script><!--Googles-->
		<script type='text/javascript' src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
	</body>
	
	
</html>
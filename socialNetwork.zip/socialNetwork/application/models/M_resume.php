<?php

class M_resume extends CI_model{

public function insert_resume($user)
{
	$this->db->insert('resume', $user);
}

public function check_resume_exist()
{
	  $uid = $this->session->userdata('user_id');
	  $query = $this->db->query('SELECT user_id FROM resume where user_id = $uid');
	  return $query->num_rows();
}
}
?>
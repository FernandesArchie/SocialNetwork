<?php

class User_model extends CI_model{



public function register_user($user){

	$this->db->insert('user', $user);

}

public function Mcreate_album($album){

	$this->db->insert('album', $album);

}
//Code Added by Me
public function Mcreate_group($group){
	$this->db->insert('group', $group);
}

function fetch_notes_id()
	{
		$query = $this->db->query("SELECT notes_id FROM notes ORDER BY notes_id DESC LIMIT 1");
		$result =  $query->result();
		$row=$result[0];
		return $row->notes_id;
	}
	
	function update_notes($nid)
	{
		$gid = $this->session->userdata('group_id');
		//echo $gid;
		//echo $nid;
		$query = $this->db->query("UPDATE `notes` SET `group_id`='$gid' WHERE `notes_id`='$nid'");
		//$result =  $query->result();
		//$query->result();
		//$row=$result[0];
		//return $row->notes_id;
	}
public function Mlists_group(){
	
	$this->db->select('*');
	$this->db->from('group');
	//where condition to fetch group dept wise
	$query=$this->db->get();
	?>
	<meta charset="utf-8">
    <title>Group Lists</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css"/>
	<!----------------------------------------------------------------------------- Nav Bar --------------------------------------------------------- -->
		<!-- <nav class="navbar navbar-inverse navbar-static-top">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="<?php echo base_url('user/user_profile');?>"><?php echo $this->session->userdata('user_fname'); ?>'s Profile</a>
				</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">

						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Activities<span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li><a href="<?php echo base_url('user/user_profile');?>">Home</a></li>
								<li><a href="<?php echo base_url('Albums/index');?>">Album</a></li>
								<li><a href="<?php echo base_url('Chat/retrieveMsg');?>">Messages</a></li>
								<li><a href="<?php echo base_url('UserPost/list_post');?>">Posts</a></li>
								<li><a href="<?php echo base_url('UserGroup/list_group');?>">Subject Group</a></li>
								<li><a href="<?php echo base_url('C_crudUser/User_list');?>">Users</a></li>
								<li><a href="<?php echo base_url('C_conference/conference_view');?>">Conference</a></li>
								<li><a href="https://appr.tc/">Video Chat</a></li>
							</ul>
						</li>
						<li><a href="<?php echo base_url('user/user_logout');?>">Log Out</a></li>
					</ul>
				</div>
			</div>
		</nav> -->
		<?php include 'header\user_header.php'; ?>
<!-------------------------------------------------------------------------------------------------------------------------------------- -->
	
	<script type='text/javascript' src="<?php echo base_url();?>assets/js/jquery-3.3.1.min.js"></script><!--Googles-->
	<script type='text/javascript' src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
	  
	<?php
	echo "<table border='1px solid black' class='table table-bordered table-striped'><th>Groups</th>";

	if ($query->num_rows() > 0) {
	foreach ($query->result() as $row) {?>
	<tr><td>
	<a href='<?php echo site_url('UserGroup/view_group/'.$row->group_id);?>'> 
	<?php echo $row->group_name; ?></a>
	</td></tr>
	<?php }
	echo "</table>";
	}
	
}
public function Mdelete_group(){
	echo($confirm ="<script>javascript:confirm('Do you wish to delete this group?');</script>");
		if ($confirm == true)
		{
			//$query="DELETE FROM group WHERE Idsoft='".$id."'";
			$group_id=$this->session->userdata('group_id');
			$this->db->delete('*');
			$this->db->from('group');
			$this->db->where('group_id',$group_id);
			$result=mysqli_query($ligabd,$query);	
			echo"deleted";			
		}
		else
		{
			echo"Not deleted";
		}
	
	
}


public function Mcreate_post($post){
	$this->db->insert('posts', $post);
}

//Code Added 10th May 2018 Jessio_____________________________________________________________________

public function Mlists_post(){
	if($this->session->userdata('fuser_id')!=null)
		$user=$this->session->userdata('fuser_id');
	else
		$user=$this->session->userdata('user_id');
	$this->db->select('*');
	$this->db->from('posts');
	$this->db->where('user_id',$user);
	$query=$this->db->get();

	//echo "<table class='table table-bordered table-striped' border='1px solid black' style='position: absolute; top: 350px;'><th>Posts</th>";

	if ($query->num_rows() > 0) {
	foreach ($query->result() as $row) {?>
	<tr><td>
	<div class="container" style='max-width: 600px;'>
	<textarea class="form-control" rows='4' cols='50' readonly style=resize:none>"<?php echo $row->body; ?>"</textarea>
	
	</div>
	</td></tr>
	<?php }
	echo "</table>";
	}
}


public function Mlists_user(){
	
	$this->db->select('*');
	$this->db->from('user');
	//where condition to fetch group dept wise
	$this->db->where('user_type',"teacher");
	$query=$this->db->get();
	?>
	<meta charset="utf-8">
    <title>User Lists</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css"/>
	<!----------------------------------------------------------------------------- Nav Bar --------------------------------------------------------- -->
		<!-- <nav class="navbar navbar-inverse navbar-static-top">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="<?php echo base_url('user/user_profile');?>"><?php echo $this->session->userdata('user_fname'); ?>'s Profile</a>
				</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">

						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Activities<span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li><a href="<?php echo base_url('user/user_profile');?>">Home</a></li>
								<li><a href="<?php echo base_url('Albums/index');?>">Album</a></li>
								<li><a href="<?php echo base_url('Chat/retrieveMsg');?>">Messages</a></li>
								<li><a href="<?php echo base_url('UserPost/list_post');?>">Posts</a></li>
								<li><a href="<?php echo base_url('UserGroup/list_group');?>">Subject Group</a></li>
								<li><a href="<?php echo base_url('C_crudUser/User_list');?>">Users</a></li>
								<li><a href="<?php echo base_url('C_conference/conference_view');?>">Conference</a></li>
								<li><a href="https://appr.tc/">Video Chat</a></li>
							</ul>
						</li>
						<li><a href="<?php echo base_url('user/user_logout');?>">Log Out</a></li>
					</ul>
				</div>
			</div>
		</nav> -->
		<?php include 'header\user_header.php'; ?>
<!-------------------------------------------------------------------------------------------------------------------------------------- -->
	
	<script type='text/javascript' src="<?php echo base_url();?>assets/js/jquery-3.3.1.min.js"></script><!--Googles-->
	<script type='text/javascript' src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
	
	<table border='1px solid black' class='table table-bordered table-striped'><th colspan='6'>Teacher List</th>
	<tr>
	<th>First Name</th>
	<th>Last Name</th>
	<th>Email</th>
	<th>DOB</th>
	<th>Mobile</th>
	<th>Address</th>
	</tr>
	<?php
	if ($query->num_rows() > 0) {
	foreach ($query->result() as $row) {?>
	<tr>
	<td><a href='<?php echo site_url('User/view_user/'.$row->user_id);?>'> 
	<?php echo $row->user_fname; ?></a></td>
	<td><?php echo $row->user_lname; ?></td>
	<td><?php echo $row->user_email; ?></td>
	<td><?php echo $row->user_dob; ?></td>
	<td><?php echo $row->user_mobile; ?></td>
	<td><?php echo $row->user_address; ?></td>
	</tr>
	<?php }
	echo "</table>";
	}
	
	$this->db->select('*');
	$this->db->from('user');
	//where condition to fetch group dept wise
	$this->db->where('user_type',"student");
	$query=$this->db->get();
	?>
	<table border='1px solid black' class='table table-bordered table-striped'><th colspan='6'>Student List</th>
	<tr>
	<th>First Name</th>
	<th>Last Name</th>
	<th>Email</th>
	<th>DOB</th>
	<th>Mobile</th>
	<th>Address</th>
	</tr>
	<?php
	if ($query->num_rows() > 0) {
	foreach ($query->result() as $row) {?>
	<tr>
	<td><a href='<?php echo site_url('User/view_user/'.$row->user_id);?>'> 
	<?php echo $row->user_fname; ?></a></td>
	<td><?php echo $row->user_lname; ?></td>
	<td><?php echo $row->user_email; ?></td>
	<td><?php echo $row->user_dob; ?></td>
	<td><?php echo $row->user_mobile; ?></td>
	<td><?php echo $row->user_address; ?></td>
	</tr>
	<?php }
	echo "</table>";
	}
}

public function set_fuser($fid){
  $this->db->select('*');
  $this->db->from('user');
  $this->db->where('user_id',$fid);
  if($query=$this->db->get())
  {
      return $query->row_array();
  }
  else{
    return false;
  }
}
//______________________________________



public function register_student($student){

	$this->db->insert('student', $student);

}

public function login_user($email,$pass){

  $this->db->select('*');
  $this->db->from('user');
  $this->db->where('user_email',$email);
  $this->db->where('user_password',$pass);

  if($query=$this->db->get())
  {
      return $query->row_array();
  }
  else{
    return false;
  }


}
public function email_check($email){

  $this->db->select('*');
  $this->db->from('user');
  $this->db->where('user_email',$email);
  $query=$this->db->get();

  if($query->num_rows()>0){
    return false;
  }else{
    return true;
  }

}

public function user_check($type){

  if($type == "student"){
    return true;
  }else{
    return false;
  }
}

function fetch_user_id()
	{
		$query = $this->db->query("SELECT user_id FROM user ORDER BY user_id DESC LIMIT 1");
		$result =  $query->result();
		$row=$result[0];
		return $row->user_id;
	}
	
	function resume_user_id()
	{
		$uid = $this->session->userdata('user_id');
		
		$query = $this->db->query("SELECT user_id FROM resume where user_id = '$uid'");
		$result =  $query->result();
		
		if($result){
			$row=$result[0];
			return $row->user_id;
		}else
			return 0;
	}


}


?>
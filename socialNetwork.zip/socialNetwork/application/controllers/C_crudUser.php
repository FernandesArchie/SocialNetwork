<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_crudUser extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->database();
		$this->load->helper('url');

		$this->load->library('grocery_CRUD');
	}

	public function _example_output($output = null)
	{
		$this->load->view('V_crudUser.php',(array)$output);
	}
	
	public function offices()
	{
		$output = $this->grocery_crud->render();

		$this->_example_output($output);
	}

	public function index()
	{
		$this->_example_output((object)array('output' => '' , 'js_files' => array() , 'css_files' => array()));
	}


	
	
//////////////////////////////////////////
	public function User_list()
	{
		?>
		<meta charset="utf-8">
		<title>User Lists</title>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css"/>
		<!----------------------------------------------------------------------------- Nav Bar --------------------------------------------------------- -->
			<!-- <nav class="navbar navbar-inverse navbar-static-top">
				<div class="container">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="<?php echo base_url('user/user_profile');?>"><?php echo $this->session->userdata('user_fname'); ?>'s Profile</a>
					</div>
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav navbar-right">

							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Activities<span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li><a href="<?php echo base_url('user/user_profile');?>">Home</a></li>
									<li><a href="<?php echo base_url('Albums/index');?>">Album</a></li>
									<li><a href="<?php echo base_url('Chat/retrieveMsg');?>">Messages</a></li>
									<li><a href="<?php echo base_url('UserPost/list_post');?>">Posts</a></li>
									<li><a href="<?php echo base_url('UserGroup/list_group');?>">Subject Group</a></li>
									<li><a href="<?php echo base_url('C_crudUser/User_list');?>">Users</a></li>
									<li><a href="<?php echo base_url('C_conference/conference_view');?>">Conference</a></li>
									<li><a href="https://appr.tc/">Video Chat</a></li>
								</ul>
							</li>
							<li><a href="<?php echo base_url('user/user_logout');?>">Log Out</a></li>
						</ul>
					</div>
				</div>
			</nav> -->
			<?php include 'header\user_header.php'; ?>
		<!-------------------------------------------------------------------------------------------------------------------------------------- -->
		
		<script type='text/javascript' src="<?php echo base_url();?>assets/js/jquery-3.3.1.min.js"></script><!--Googles-->
		<script type='text/javascript' src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
		<?php
		$crud = new grocery_CRUD();

		$crud->set_table('user');
		
		$crud->field_type('user_password', 'readonly');
		$crud->unset_columns('user_password');
		$crud->unset_delete();
		$crud->unset_edit();
		$crud->unset_clone();
		$crud->unset_add();
		$output = $crud->render();

		$this->_example_output($output);
	}

	
	

	

}

<?php
 
class UserPost extends CI_Controller {
 
public function __construct(){
 
        parent::__construct();
  			$this->load->helper('url');
  	 		$this->load->model('user_model');
        $this->load->library('session');
 
}
 
public function index()
{
$this->load->view("create_post");
}

public function Acreate_post(){
	
	
	  $post=array(
      'body'=> $this->input->post('post_name'),
	  'user_id'=> $this->session->userdata('user_id'),
	  'time'=>time(),
	  'date_added'=>date("Y/m/d")
        );
		
	  $this->user_model->Mcreate_post($post);
	  echo "Status posted Successfully";
	  redirect('UserPost/list_post');
}

function load_post(){
 $this->load->view("create_post.php");
}

function list_post(){
	$this->load->view("list_post.php");
	echo "<table class='table table-bordered table-striped' border='1px solid black' style='position: absolute; top: 350px;'><th>Posts</th>";
	$this->user_model->Mlists_post();
}

}
?>
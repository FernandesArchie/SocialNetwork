

<nav class="navbar navbar-inverse navbar-static-top">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="<?php echo base_url('user/user_profile');?>"><?php echo $this->session->userdata('user_fname'); ?>'s Profile</a>
				</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">

					
					<li><a href="<?php echo base_url('user/user_profile');?>">Home</a></li>
						
					
					<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Resume<span class="caret"></span></a>
							<ul class="dropdown-menu">
								<?php
									$uid = $this->session->userdata('user_id');
									$rid = $this->session->userdata('resume_user_id');
									if($uid != $rid) {
								?>
								<li><a href="<?php echo base_url('C_resume/resume_view');?>">Create resume</a></li>
								<?php } ?>
								<li><a href="<?php echo base_url('C_resume/resume');?>">Resume</a></li>
								<li><a href="<?php echo base_url('C_resume/std_resume');?>">Edit/View resume</a></li>
								<?php if($uid == $rid) { ?>
								<li><a href="<?php echo base_url('C_resume/print_resume');?>">Print resume</a></li>
								<?php } ?>
								
							</ul>
						</li>
					
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Activities<span class="caret"></span></a>
							<ul class="dropdown-menu">
								<!--<li><a href="<?php echo base_url('user/user_profile');?>">Home</a></li>-->
								<li><a href="<?php echo base_url('Albums/index');?>">Album</a></li>
								<li><a href="<?php echo base_url('Chat/retrieveMsg');?>">Messages</a></li>
								<li><a href="<?php echo base_url('UserPost/list_post');?>">Posts</a></li>
								<li><a href="<?php echo base_url('UserGroup/list_group');?>">Subject Group</a></li>
								<li><a href="<?php echo base_url('C_crudUser/User_list');?>">Find Users</a></li>
								<li><a href="<?php echo base_url('user/lists_user');?>">Users</a></li>
								<li><a href="<?php echo base_url('C_conference/conference_view');?>">Conference</a></li>
								<li><a href="https://appr.tc/">Video Chat</a></li>
								
							</ul>
						</li>
						<li><a href="<?php echo base_url('user/user_logout');?>">Log Out</a></li>
					</ul>
				</div>
			</div>
		</nav>

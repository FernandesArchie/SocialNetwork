<?php
 
class User extends CI_Controller {
 
public function __construct(){
 
        parent::__construct();
  			$this->load->helper('url');
  	 		$this->load->model('user_model');
        $this->load->library('session');
 
}
 
public function index()
{
$this->load->view("home.php");
}
 
public function register_user(){
 
      $user=array(
      'user_fname'=>$this->input->post('user_fname'),
	  'user_lname'=>$this->input->post('user_lname'),
      'user_email'=>$this->input->post('user_email'),
      'user_password'=>md5($this->input->post('user_password')),
      'user_dob'=>$this->input->post('user_dob'),
      'user_mobile'=>$this->input->post('user_mobile'),
	  'user_address'=>$this->input->post('user_address'),
	  'user_deptName'=>$this->input->post('user_deptName'),
	  'user_type'=>$this->input->post('user_type')
        );
       // print_r($user);
	   
	  
 
	$user_check = $this->user_model->user_check($user['user_type']);
	
	$email_check = $this->user_model->email_check($user['user_email']);
 
	if($email_check){
	  $this->user_model->register_user($user);
	  $this->session->set_flashdata('success_msg', 'Registered successfully.Now login to your account.');
	  
	  if($user_check)
	  {
		 $user_id = $this->user_model->fetch_user_id();
		 $student=array(
		  'std_roll'=>$this->input->post('std_roll'),
		  'std_joinDate'=>$this->input->post('std_joinDate'),
		  'user_id'=>$user_id		  
		  );
		 $this->user_model->register_student($student);
	  }
	  
	  redirect('user/login_view'); 
	}
	else{
	 
	  $this->session->set_flashdata('error_msg', 'Error occured,Try again.');
	  redirect('user');
	}
 
}
 
public function login_view(){
 
$this->load->view("login.php");
 
}
 
function login_user(){
  $user_login=array(
 
  'user_email'=>$this->input->post('user_email'),
  'user_password'=>md5($this->input->post('user_password'))
 
    );
 
    $data=$this->user_model->login_user($user_login['user_email'],$user_login['user_password']);
      if($data)
      {
        $this->session->set_userdata('user_id',$data['user_id']);
        $this->session->set_userdata('user_email',$data['user_email']);
        $this->session->set_userdata('user_fname',$data['user_fname']);
		$this->session->set_userdata('user_type',$data['user_type']);
        $this->session->set_userdata('user_dob',$data['user_dob']);
        $this->session->set_userdata('user_mobile',$data['user_mobile']);
		
		 $data1=$this->user_model->resume_user_id();    
		 $this->session->set_userdata('resume_user_id',$data1);
		
		
		$this->load->view('user_home.php');
 
      }
      else{
        $this->session->set_flashdata('error_msg', 'Error occured,Try again.');
        $this->load->view("login.php");
 
      }
 
 
}
 
function user_profile(){
 
//$this->load->view('user_profile.php');
$this->load->view('user_home.php');
 
}

function user_info(){
 
$this->load->view('user_profile.php');
//$this->load->view('user_home.php');
 
}


public function user_logout(){
 
  $this->session->sess_destroy();
  redirect('user/login_view', 'refresh');
}

//Code Added 10th May 2018 Jessio________________________________________________________________
function lists_user(){
 $this->user_model->Mlists_user();
}
function view_user($fid){
	//$this->session->set_userdata('fuser_id', $fid);
	$fdata=$this->user_model->set_fuser($fid);
	$this->session->set_userdata('fuser_id',$fdata['user_id']);
	$this->session->set_userdata('fuser_email',$fdata['user_email']);
	$this->session->set_userdata('fuser_fname',$fdata['user_fname']);
	$this->session->set_userdata('fuser_type',$fdata['user_type']);
	$this->session->set_userdata('fuser_dob',$fdata['user_dob']);
	$this->session->set_userdata('fuser_mobile',$fdata['user_mobile']);
	$this->load->view("view_user.php");
	echo "<table class='table table-bordered table-striped' border='1px solid black' style='position: absolute; top: 500px;'><th>Posts</th>";
	$this->user_model->Mlists_post();
}
//_________________________________________________________________________

 
}
 
?>
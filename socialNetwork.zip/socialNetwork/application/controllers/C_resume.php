<?php
 
class C_resume extends CI_Controller {
 
public function __construct(){
 
        parent::__construct();
  			$this->load->helper('url');
  	 		$this->load->model('M_resume');
        $this->load->library('session');
		$this->load->library('upload');
		$this->load->library('grocery_CRUD');
 
}
 
public function resume_view()
{
$this->load->view("V_resume.php");
}

public function print_resume()
{
$this->load->view("resume_pdf.php");
}
 
public function insert_resume(){
 		
					
       $user=array(
      'firstName'=>$this->input->post('user_fname'),
	  'lastName'=>$this->input->post('user_lname'),
	  'email'=>$this->session->userdata('user_email'),
	  'gender'=>$this->input->post('gender'),
	  'dob'=>$this->session->userdata('user_dob'),
	  'Mobile'=>$this->session->userdata('user_mobile'),
	  'address' =>$this->input->post('address'),
	  'hobbies' =>$this->input->post('hobbies'),
	  'lang_spoken' =>$this->input->post('lang_spoken'),
	  'ssc_Name' =>$this->input->post('ssc_Name'),
	  'Hssc_Name' =>$this->input->post('Hssc_Name'),
	  'college_Name'=>$this->input->post('college_Name'),
	  'ssc_Mks' =>$this->input->post('ssc_Mks'),
	  'Hssc_Mks' =>$this->input->post('Hssc_Mks'),
	  'college_Mks'=>$this->input->post('college_Mks'),
	  'ssc_YOP'=>$this->input->post('ssc_YOP'),
	  'Hssc_YOP'=>$this->input->post('Hssc_YOP'),
	  'college_YOP'=>$this->input->post('college_YOP'),
	  'Wrk_exp'=>$this->input->post('Wrk_exp'),
	  'descp'=>$this->input->post('descp'),
	  'user_id'=>$this->session->userdata('user_id')
        );
       // print_r($user);
			
	  $this->M_resume->insert_resume($user);
	  }
	  
	  
	  public function resume()
	{
			$crud = new grocery_CRUD();

			$crud->set_table('resume');
			$crud->unset_columns('hobbies','lang_spoken','ssc_Name','ssc_Mks','ssc_YOP','Hssc_Name','Hssc_Mks','Hssc_YOP','college_Name','college_Mks','college_YOP','Wrk_exp','descp','gender','user_id');

			$crud->display_as('hobbies','Hobbies')
				 ->display_as('lang_spoken','Languages Spoken')
				 ->display_as('Wrk_exp','Work Experience')
				  ->display_as('descp','Description')
				  ->display_as('dob','Date Of Birth')
				 ->display_as('ssc_YOP','Year Of Passing')
				 ->display_as('Hssc_YOP','Year Of Passing')
				 ->display_as('college_YOP','Year Of Passing')
				 ->display_as('ssc_Mks','Marks Obtained')
				 ->display_as('Hssc_Mks','Marks Obtained')
				 ->display_as('college_Mks','Marks Obtained')
				 ->display_as('college_Name','College Name')
				 ->display_as('Hssc_Name','Higher Secondary School Name')
				 ->display_as('ssc_Name','School Name');
			
			/*$crud->columns('customerName','contactLastName','phone','city','country','salesRepEmployeeNumber','creditLimit');
			$crud->display_as('salesRepEmployeeNumber','from Employeer')
				 ->display_as('customerName','Name')
				 ->display_as('contactLastName','Last Name');
			$crud->set_subject('Customer');
			$crud->set_relation('salesRepEmployeeNumber','employees','lastName');*/

			
			$crud->unset_add();
			$crud->unset_edit();
			$crud->unset_delete();
			
			$output = $crud->render();

			$this->_example_output($output);
	}
	public function std_resume()
	{
			$crud = new grocery_CRUD();
			/*new*/
			$data =$this->session->userdata('user_id');
			$crud->set_table('resume');
			/*$crud->columns('customerName','contactLastName','phone','city','country','salesRepEmployeeNumber','creditLimit');
			$crud->display_as('salesRepEmployeeNumber','from Employeer')
				 ->display_as('customerName','Name')
				 ->display_as('contactLastName','Last Name');
			$crud->set_subject('Customer');
			$crud->set_relation('salesRepEmployeeNumber','employees','lastName');*/
			
			
			$crud->display_as('hobbies','Hobbies')
				 ->display_as('lang_spoken','Languages Spoken')
				 ->display_as('Wrk_exp','Work Experience')
				  ->display_as('descp','Description')
				  ->display_as('dob','Date Of Birth')
				 ->display_as('ssc_YOP','Year Of Passing')
				 ->display_as('Hssc_YOP','Year Of Passing')
				 ->display_as('college_YOP','Year Of Passing')
				 ->display_as('ssc_Mks','Marks Obtained')
				 ->display_as('Hssc_Mks','Marks Obtained')
				 ->display_as('college_Mks','Marks Obtained')
				 ->display_as('college_Name','College Name')
				 ->display_as('Hssc_Name','Higher Secondary School Name')
				 ->display_as('ssc_Name','School Name');
			/*new*/
			$crud->set_model('custom_query_model');
			$crud->unset_columns('hobbies','lang_spoken','ssc_Name','ssc_Mks','ssc_YOP','Hssc_Name','Hssc_Mks','Hssc_YOP','college_Name','college_Mks','college_YOP','Wrk_exp','descp','gender','user_id');
				$crud->basic_model->set_query_str("SELECT * FROM resume where user_id='$data'");
				
			$crud->unset_add();
			//$crud->unset_edit();
			$crud->unset_delete();
			$crud->field_type('user_id', 'readonly');
			$output = $crud->render();

			$this->_example_output($output);
	}
	
	
	
	public function _example_output($output = null)
	{
		$this->load->view('resume.php',(array)$output);
	}
	public function index()
	{
		$this->_example_output((object)array('output' => '' , 'js_files' => array() , 'css_files' => array()));
	}
	  
}
?>
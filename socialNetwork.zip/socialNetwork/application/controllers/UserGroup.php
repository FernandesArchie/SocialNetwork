<?php
 
class UserGroup extends CI_Controller {
 
public function __construct(){
 
        parent::__construct();
  			$this->load->helper('url');
  	 		$this->load->model('user_model');
        $this->load->library('session');
 
}
 
public function index()
{
$this->load->view("create_group");
}

public function Acreate_group(){
	
	  
	  $group=array(
      'group_name'=> $this->input->post('group_name'),
	  'user_id'=> $this->session->userdata('user_id')
        );
		
	  $this->user_model->Mcreate_group($group);
	  echo "Group Created Successfully";
}

function create_group(){
 $this->load->view("create_group.php");
}
 
function list_group(){
 $this->load->view("list_group.php");
  //$this->user_model->Mlists_group();
}
function lists_group(){
 $this->user_model->Mlists_group();
}

function view_group($gid){
	//echo $gid;
	$this->session->set_userdata('group_id', $gid);
	$this->load->view("view_group.php");
	}


function delete_group(){
	$this->load->view("view_group.php");
	//$this->user_model->Mdelete_group();
}
} 
?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chat extends CI_Controller {

	public function __construct(){
	 
			parent::__construct();
				$this->load->helper('url');
				$this->load->model('Chat_model');
				$this->load->library('session');
				$this->load->helper('date');
				error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
	}

	public function index()
	{
		$this->load->helper('url');
		$this->load->model('Chat_model');
		$this->load->library('session');
		
		//$this->load->view('chat');
		
		    //$this->load->library('mahana_messaging');
			//$msg = $this->mahana_messaging->get_message($msg_id, $sender_id);
	}
	
	/*
	public function startChat()
	{
		//$this->load->library('session');
		//$this->load->view('chat');
		    $this->load->library('mahana_messaging');
			$msg_id=1;
			$sender_id=$this->session->userdata('user_id');
			$msg = $this->mahana_messaging->get_message($msg_id, $sender_id);
	}
	
	public function sendChat($message, $nickname, $guid)
	{
		//$this->load->library('session');
		//$this->load->view('chat');
		   $this->Chat_model->add_message($message, $nickname, $guid);
	}
	*/
	
	public function storeMsg()
	{
		$datestring = 'Year: %Y Month: %m Day: %d - %h:%i %a';
		$time = time();
		//$dtm= mdate($datestring, $time);
		//$this->load->library('session');
		//$this->load->view('chat');
		$now = date('Y-m-d H:i:s');
		   $chats=array(
			  'receiver'=>$this->input->post('receiver'),
			  'message'=>$this->input->post('message'),
			  'sender'=>$this->session->userdata('user_fname'),
			  'dt'=>$now
				);
				
			$this->Chat_model->saveMsg($chats);
	}
	
	public function retrieveMsg()
	{
		//$this->load->library('session');
		//$this->load->view('chat');
		 $query = $this->Chat_model->getMsg();
		  $data['msgs'] = null;
		  if($query){
		   $data['msgs'] =  $query;
		  }
		
		  $this->load->view('chat.php', $data);
			
	}
	
	public function vSentMsg()
	{
		//$this->load->library('session');
		//$this->load->view('chat');
		 $query = $this->Chat_model->getSentMsg();
		  $data['msgs'] = null;
		  if($query){
		   $data['msgs'] =  $query;
		  }
		
		  $this->load->view('sentchat.php', $data);
			
	}
}